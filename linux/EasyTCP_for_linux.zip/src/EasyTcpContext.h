#ifndef EASYTCPCONTEXT_H
#define EASYTCPCONTEXT_H

#include <memory>
#include <functional>
#include <sys/epoll.h>

namespace EasyTcp
{
    namespace Context
    {

        class Context : public epoll_event
        {
        public:
            Context(std::function<void(uint32_t)> callback);
            ~Context();

            void update(uint32_t events);

        private:
            std::function<void(uint32_t)> m_callback;
        };
        typedef std::shared_ptr<Context> SPTRContext;
    }
}

#endif
